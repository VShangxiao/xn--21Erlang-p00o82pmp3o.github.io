-module(seq3).

-export([b/1]).

% SNIP BEGIN seq-b
b(_) -> 1.
% SNIP END
