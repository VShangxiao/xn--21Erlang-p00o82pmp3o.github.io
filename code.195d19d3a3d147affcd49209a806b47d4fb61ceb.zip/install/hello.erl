-module(hello).

-export([world/0]).

world() -> "Hello, world!".
