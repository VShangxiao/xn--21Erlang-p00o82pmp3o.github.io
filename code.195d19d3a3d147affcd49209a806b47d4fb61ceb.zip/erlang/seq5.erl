-module(seq5).

-export([b/1]).

b(N) when N >= 1 -> 1.
